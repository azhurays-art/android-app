package com.example.nfccardreader

import android.app.Activity
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), NfcAdapter.ReaderCallback {
    private var nfcAdapter: NfcAdapter? = null
    private lateinit var status: TextView
    private lateinit var details: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        nfcAdapter = NfcAdapter.getDefaultAdapter(this)

        val title = TextView(this).apply {
            text = "NFC Card Reader"
            textSize = 25f
            setPadding(0, 0, 0, 18)
        }
        status = TextView(this).apply {
            textSize = 18f
            text = when {
                nfcAdapter == null -> "Perangkat ini tidak memiliki NFC."
                nfcAdapter?.isEnabled != true -> "NFC belum aktif. Aktifkan melalui Pengaturan."
                else -> "Siap memindai. Tempelkan kartu NFC di bagian belakang HP."
            }
            setPadding(0, 0, 0, 18)
        }
        details = TextView(this).apply {
            textSize = 15f
            text = "Hasil pemindaian akan muncul di sini.\n\nAplikasi ini hanya membaca informasi identifikasi dan teknologi yang diumumkan kartu. Tidak menulis, menyalin, atau mengubah kredensial kartu."
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            addView(title)
            addView(status)
            addView(details)
        }
        val scroll = ScrollView(this).apply { addView(content) }
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        val adapter = nfcAdapter ?: return
        if (adapter.isEnabled) {
            val flags = NfcAdapter.FLAG_READER_NFC_A or
                    NfcAdapter.FLAG_READER_NFC_B or
                    NfcAdapter.FLAG_READER_NFC_F or
                    NfcAdapter.FLAG_READER_NFC_V or
                    NfcAdapter.FLAG_READER_NO_PLATFORM_SOUNDS
            adapter.enableReaderMode(this, this, flags, null)
            runOnUiThread {
                status.text = "Siap memindai. Tempelkan kartu NFC di bagian belakang HP."
            }
        } else {
            status.text = "NFC belum aktif. Aktifkan melalui Pengaturan."
        }
    }

    override fun onPause() {
        nfcAdapter?.disableReaderMode(this)
        super.onPause()
    }

    override fun onTagDiscovered(tag: Tag) {
        val uid = tag.id.joinToString("") { "%02X".format(it) }
        val techs = tag.techList.map { it.substringAfterLast('.') }.distinct()
        val timestamp = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault()).format(Date())

        val report = buildString {
            appendLine("Waktu: $timestamp")
            appendLine()
            appendLine("UID (jika tersedia): $uid")
            appendLine()
            appendLine("Teknologi yang terdeteksi:")
            techs.forEach { appendLine("• $it") }
            appendLine()
            append("Catatan: daftar teknologi tidak menjamin kartu dapat dibaca penuh atau ditulis ulang. Kartu yang memakai autentikasi/enkripsi memerlukan mekanisme resmi dari penerbit.")
        }

        runOnUiThread {
            status.text = "Kartu terdeteksi."
            details.text = report
        }
    }
}
