# NFC Card Reader

Aplikasi Android sederhana untuk diagnostik NFC secara read-only.

## Fitur
- Mendeteksi kartu NFC saat ditempelkan.
- Menampilkan UID jika tersedia dan daftar teknologi yang diumumkan tag.
- Tidak menulis, menyalin, mengubah, atau menyimpan kredensial kartu.

## Cara membuka dan membuat APK
1. Ekstrak ZIP ini.
2. Buka folder `NFCCardReader` melalui Android Studio.
3. Tunggu Gradle Sync selesai.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Pasang APK hasil build pada Redmi Note 13 5G.
6. Aktifkan NFC di Pengaturan HP, lalu buka aplikasi dan tempelkan kartu.

Catatan: build pertama memerlukan koneksi internet untuk mengunduh komponen Gradle/Android yang dibutuhkan. Gunakan hanya pada kartu yang memang boleh Anda periksa.
